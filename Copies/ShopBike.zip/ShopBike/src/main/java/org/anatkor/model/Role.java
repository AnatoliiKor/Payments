package org.anatkor.model;

public enum Role {
    USER,
    ADMIN
}