package org.anatkor.controllers;

public class UserController {
}
